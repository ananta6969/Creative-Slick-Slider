// Init Slick nav slider
$('.js-nav-slider').slick({
  dots: false,
  infinite: true,
  speed: 400,
  slidesToShow: 4,
  slidesToScroll: 1,
  variableWidth: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});

// Build custom numbered dots
const totalSlides = $('.image-slider-col').length;
for (let i = 0; i < totalSlides; i++) {
  $('.custom-dots').append(`<span>${i + 1}</span>`);
}

// Set initial active
$('.image-slider-col').eq(0).addClass('current');
$('.custom-dots span').eq(0).addClass('active');

// Function to move animate-title__list
function moveTitle(index) {
  const itemHeight = 62; // Height of one title
  const offset = -index * itemHeight;
  $('.animate-title__list').css('transform', `translateY(${offset}px)`);
}

// Sync current slide with dots and image
$('.js-nav-slider').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
  $('.image-slider-col').removeClass('current');
  $('.image-slider-col').eq(nextSlide).addClass('current');

  $('.custom-dots span').removeClass('active');
  $('.custom-dots span').eq(nextSlide).addClass('active');

  // Move title based on nextSlide
  moveTitle(nextSlide);
});

// Click dots to jump to slide
$('.custom-dots').on('click', 'span', function() {
  const index = $(this).index();
  $('.js-nav-slider').slick('slickGoTo', index);
  moveTitle(index);
});

// Set initial title position
moveTitle(0);